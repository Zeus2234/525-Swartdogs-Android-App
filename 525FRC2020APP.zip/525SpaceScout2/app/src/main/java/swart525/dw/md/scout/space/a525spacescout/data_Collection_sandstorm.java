package swart525.dw.md.scout.space.a525spacescout;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;


public class data_Collection_sandstorm extends AppCompatActivity {

    //Defines variables for use
    public static String Hab_Start_Level = "1";
    public static String Crossed_Hab_Line_str = "FALSE";
    public static String cargo_Placement = "none";
    public static String Hatch_Panel_Placement = "none";
    public static String Add_Hatch = "0";
    public static String Add_Cargo = "0";
    public static String second_Cargo = "FALSE";
    public static String second_Hatch = "FALSE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data__collection_sandstorm);

        //Defines all checkboxes for positions
        final RadioButton Level_one = (RadioButton) findViewById(R.id.Level_One);
        final RadioButton Level_two = (RadioButton) findViewById(R.id.Level_Two);

        //Defines all checkboxes for field element
        final CheckBox cargo_rocket = (CheckBox) findViewById(R.id.cargo_rocket);
        final CheckBox cargo_cargoship = (CheckBox) findViewById(R.id.cargo_cargoship);
        final CheckBox Hatch_pan_Rocket = (CheckBox) findViewById(R.id.Hatch_pan_rocket);
        final CheckBox Hatch_pan_Cargoship = (CheckBox) findViewById(R.id.Hatch_panel_cargoship);
        final CheckBox Crossed_HAB_Line = (CheckBox) findViewById(R.id.Crossed_HAB_Line);
        final CheckBox Extra_Cargo = (CheckBox) findViewById(R.id.second_Cargo);
        final CheckBox Extra_Hatch = (CheckBox) findViewById(R.id.second_Hatch);

        //Defines and implements Button to continue along with variable savings
        Button To_Teleop = (Button) findViewById(R.id.To_Teleop);
        To_Teleop.setOnClickListener(new View.OnClickListener()
        { //Makes onclick listener for button
            @Override
            public void onClick(View v) {

                /*add in data collection pieces from checkboxes*/
                if (Level_one.isChecked()) {
                    Hab_Start_Level = "1";
                }
                if (Level_two.isChecked()) {
                    Hab_Start_Level = "2";
                }

                //Crossed HAB Line
                if (Crossed_HAB_Line.isChecked()) {
                    Crossed_Hab_Line_str = "TRUE";
                }

                //Below this needs to be checked for accuracy
                if (cargo_rocket.isChecked() || cargo_cargoship.isChecked()) {
                    if (cargo_rocket.isChecked() && !cargo_cargoship.isChecked()) {
                        cargo_Placement = "Rocket";
                        Add_Cargo = "1";
                    }
                    else if (cargo_cargoship.isChecked() && !cargo_rocket.isChecked()) {
                        cargo_Placement = "Cargo Ship";
                        Add_Cargo = "1";
                    }
                    else if (cargo_rocket.isChecked() && cargo_cargoship.isChecked()) {
                        cargo_Placement = "Rocket and Cargo Ship";
                        Add_Cargo = "2";
                    }
                }
                if (Hatch_pan_Cargoship.isChecked() || Hatch_pan_Rocket.isChecked()) {
                    if (Hatch_pan_Rocket.isChecked() && !Hatch_pan_Cargoship.isChecked()) {
                        Hatch_Panel_Placement = "Rocket";
                        Add_Hatch = "1";
                    }
                    else if (Hatch_pan_Cargoship.isChecked() && !Hatch_pan_Rocket.isChecked()) {
                        Hatch_Panel_Placement = "Cargo Ship";
                        Add_Hatch = "1";
                    }
                    else if (Hatch_pan_Rocket.isChecked() && Hatch_pan_Cargoship.isChecked()) {
                        Hatch_Panel_Placement = "Rocket and Cargo Ship";
                        Add_Hatch = "2";
                    }
                }
                if (Extra_Cargo.isChecked()){
                    second_Cargo = "TRUE";
                }
                if (Extra_Hatch.isChecked()){
                    second_Hatch = "TRUE";
                }
                if (second_Cargo.equals("TRUE")){
                    Add_Cargo = Integer.toString(Integer.parseInt(Add_Cargo) + 1);
                }
                if(second_Hatch.equals("TRUE")){
                    Add_Hatch = Integer.toString(Integer.parseInt(Add_Hatch) + 1);
                }

                Intent startintent = new Intent(getApplicationContext(), data_collection_TeleOP.class);
                startActivity(startintent);
            }
        });

    }

}
