package swart525.dw.md.scout.space.a525spacescout;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Save_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save__page);

        //Defines Buttons
        Button Submit_Data = (Button) findViewById(R.id.Submit_To_Store);
        Button Delete_Data = (Button) findViewById(R.id.Delete_Data);

        //Takes you to the page in order to delete the data and confirm the decision
        Delete_Data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startintent = new Intent(getApplicationContext(), Delete_Data.class);
                startActivity(startintent);
            }
        });
        //Goes to Submit page and submits data
        Submit_Data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startintent = new Intent(getApplicationContext(), Actual_Submit.class);
                startActivity(startintent);
            }
        });


        //----------------------------------------------------------------------------------------------------------------

    }
}

