package swart525.dw.md.scout.space.a525spacescout;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Actual_Submit extends AppCompatActivity {

    //Names the file it will be saved to
    public String fileName = "ScoutingData";

    //Compiles string for CSV file
    public String Final_String = "\n" + Data_Collection_Page_1.Team_Num + "," + Data_Collection_Page_1.Match_Num + "," +
            data_Collection_sandstorm.Hab_Start_Level + "," +
            data_Collection_sandstorm.Crossed_Hab_Line_str + "," + data_Collection_sandstorm.cargo_Placement + "," +
            data_Collection_sandstorm.Hatch_Panel_Placement + "," + data_Collection_sandstorm.second_Cargo + "," +
            data_Collection_sandstorm.second_Hatch + "," +
            data_collection_TeleOP.Cargo_Moved + "," + data_collection_TeleOP.Hatch_Panels_Moved + "," +
            data_collection_TeleOP.Cargo_Place_RK_Bot + "," + data_collection_TeleOP.Cargo_Place_RK_Mid + "," +
            data_collection_TeleOP.Cargo_Place_RK_Top + "," + data_collection_TeleOP.Cargo_Place_CargoShip + "," +
            data_collection_TeleOP.Hatch_Panel_RK_Bot + "," + data_collection_TeleOP.Hatch_Panel_RK_Mid + "," +
            data_collection_TeleOP.Hatch_Panel_RK_Top + "," + data_collection_TeleOP.Hatch_Panel_CargoShip + "," +
            data_collection_end_game.Ending_HAB_Location + "," + data_collection_end_game.Played_Defense +
            "," + data_collection_end_game.def_foul +
            "," + data_collection_end_game.Robot_Tipped + "," + data_collection_end_game.Robot_Stalled + "," +
            data_collection_end_game.Robot_Attempted_Climb + "," + Data_Collection_Page_1.Initials;

    File externalStorageDir = Environment.getExternalStorageDirectory();
    public File Scout_Data = new File(externalStorageDir , "/ScoutData/AppScoutingDataRed3.csv");

    /*@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actual__submit);
        Button Press_Here = (Button) findViewById(R.id.Press_Here);
        Button Click_to_go_Back = (Button) findViewById(R.id.Backto);

        Click_to_go_Back.setOnClickListener(new View.OnClickListener(){//Makes onclick listener for button
            @Override
            public void onClick(View v) {
                Intent startintent = new Intent(getApplicationContext(), Start_Page.class);
                startActivity(startintent);
            }
        });
    } */


    //Checks for confirmation from external storage
        private boolean isExternalStorageWritable () {
            if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
                Log.i("State", "Yes, it is writable!");
                return true;
            } else {
                return false;
            }
        }

        public void Press_Here (View v){
            if (isExternalStorageWritable() && checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                if(Scout_Data.exists() && Scout_Data.isFile() ){
                    try {
                        final Button Press_Here = (Button) findViewById(R.id.Press_Here);
                        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(Scout_Data, true)));
                        out.println(Final_String);
                        out.close();
                        Toast.makeText(this, "File Saved", Toast.LENGTH_LONG).show();
                        Press_Here.setVisibility(View.GONE);
                        Intent startintent = new Intent(getApplicationContext(), Start_Page.class);
                        startActivity(startintent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    File textFile = new File(Environment.getExternalStorageDirectory().getPath() + "/ScoutData", "AppScoutingDataRed3.csv");
                    try {
                        final Button Press_Here = (Button) findViewById(R.id.Press_Here);
                        FileOutputStream fos = new FileOutputStream(textFile);
                        fos.write(Final_String.getBytes());
                        fos.close();
                        Toast.makeText(this, "File Saved", Toast.LENGTH_LONG).show();
                        Press_Here.setVisibility(View.GONE);
                        Intent startintent = new Intent(getApplicationContext(), Start_Page.class);
                        startActivity(startintent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

    public boolean checkPermission (String permission) {
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_actual__submit);
            final Button Press_Here = (Button) findViewById(R.id.Press_Here);
            Press_Here.setVisibility(View.VISIBLE);

    }
}










