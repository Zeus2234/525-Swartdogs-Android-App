package swart525.dw.md.scout.space.a525spacescout;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

public class data_collection_TeleOP extends AppCompatActivity {

    //Defines variables for data collection
    public static String Cargo_Moved = "0";
    public static String Hatch_Panels_Moved = "0";
    public static String Panel_off_ground = "FALSE";
    public static String Cargo_Place_RK_Bot = "FALSE";
    public static String Cargo_Place_RK_Mid = "FALSE";
    public static String Cargo_Place_RK_Top = "FALSE";
    public static String Cargo_Place_CargoShip = "FALSE";
    public static String Hatch_Panel_RK_Bot = "FALSE";
    public static String Hatch_Panel_RK_Mid = "FALSE";
    public static String Hatch_Panel_RK_Top = "FALSE";
    public static String Hatch_Panel_CargoShip = "FALSE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_collection__tele_op);

        //Defines all checkboxes
        final CheckBox Cargo_Rk_bot = (CheckBox) findViewById(R.id.Cargo_Rk_Bot);
        final CheckBox Cargo_Rk_Mid = (CheckBox) findViewById(R.id.Cargo_Rk_Mid);
        final CheckBox Cargo_Rk_Top = (CheckBox) findViewById(R.id.Cargo_Rk_Top);
        final CheckBox Cargo_CargoShip = (CheckBox) findViewById(R.id.Cargo_Cargo_Ship);
        final CheckBox Hatch_Rk_bot = (CheckBox) findViewById(R.id.Hat_Rk_Bot);
        final CheckBox Hatch_Rk_Mid = (CheckBox) findViewById(R.id.Hat_Rk_Mid);
        final CheckBox Hatch_Rk_Top = (CheckBox) findViewById(R.id.Hat_Rk_Top);
        final CheckBox Hatch_CargoShip = (CheckBox) findViewById(R.id.Hat_Cargo_Ship);

        //Defines "Elegant" Number Blocks
        final ElegantNumberButton Cargo_Moved_Txt = (ElegantNumberButton) findViewById(R.id.Cargo_Moved);
        final ElegantNumberButton Hatches_Moved_Txt = (ElegantNumberButton) findViewById(R.id.Hatches_Moved);

        //Below defines the button and commands for saving data and switching pages
        Button To_EndGame = (Button) findViewById(R.id.To_Endgame);
        To_EndGame.setOnClickListener(new View.OnClickListener()
        { //Makes onclick listener for button
            @Override
            public void onClick(View v) {
                int Cargo_Compare = Integer.parseInt(Cargo_Moved_Txt.getNumber());
                int Hatch_Compare = Integer.parseInt(Hatches_Moved_Txt.getNumber());
                if((Cargo_Compare > 15) || (Hatch_Compare > 15)){
                    Toast.makeText(data_collection_TeleOP.this, "If a robot has delivered more than 15 hatches or cargo, please alert a paper scouter", Toast.LENGTH_LONG).show();
                }else{
                    Hatch_Panels_Moved = Integer.toString(Integer.parseInt(Hatches_Moved_Txt.getNumber()) + Integer.parseInt(data_Collection_sandstorm.Add_Hatch));
                    Cargo_Moved = Integer.toString(Integer.parseInt(Cargo_Moved_Txt.getNumber()) + Integer.parseInt(data_Collection_sandstorm.Add_Cargo));
                    if(Cargo_Rk_bot.isChecked()){
                        Cargo_Place_RK_Bot = "TRUE";
                    }
                    if(Cargo_Rk_Mid.isChecked()){
                        Cargo_Place_RK_Mid = "TRUE";
                    }
                    if(Cargo_Rk_Top.isChecked()){
                        Cargo_Place_RK_Top = "TRUE";
                    }
                    if(Cargo_CargoShip.isChecked()){
                        Cargo_Place_CargoShip = "TRUE";
                    }
                    if(Hatch_Rk_bot.isChecked()){
                        Hatch_Panel_RK_Bot = "TRUE";
                    }
                    if(Hatch_Rk_Mid.isChecked()){
                        Hatch_Panel_RK_Mid = "TRUE";
                    }
                    if(Hatch_Rk_Top.isChecked()){
                        Hatch_Panel_RK_Top = "TRUE";
                    }
                    if(Hatch_CargoShip.isChecked()){
                        Hatch_Panel_CargoShip = "TRUE";
                    }
                    Intent startintent = new Intent(getApplicationContext(), data_collection_end_game.class);
                    startActivity(startintent);
                }
            }
        });
    }
}
