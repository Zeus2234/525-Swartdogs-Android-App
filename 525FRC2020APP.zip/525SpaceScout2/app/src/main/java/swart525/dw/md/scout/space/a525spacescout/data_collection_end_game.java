package swart525.dw.md.scout.space.a525spacescout;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class data_collection_end_game extends AppCompatActivity {

    //Defines needed variables
    public static String Ending_HAB_Location = "No_data";
    public static String Played_Defense = "FALSE";
    public static String Robot_Tipped = "FALSE";
    public static String Robot_Stalled = "FALSE";
    public static String Robot_Attempted_Climb = "FALSE";
    public static String def_foul = "FALSE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_collection_end_game);

        //Defines Page Elements
        final RadioButton Hab_Level_One = (RadioButton) findViewById(R.id.Hab_Level_one);
        final RadioButton Hab_Level_Two = (RadioButton) findViewById(R.id.Hab_Level_two);
        final RadioButton Hab_Level_Three = (RadioButton) findViewById(R.id.Hab_Level_three);
        final RadioButton No_Hab = (RadioButton) findViewById(R.id.No_Hab);
        final RadioButton Attempt_Level_Two = (RadioButton) findViewById(R.id.Attempt_Two);
        final RadioButton Attempt_Level_Three = (RadioButton) findViewById(R.id.Attempt_Three);

        final RadioGroup RadioGroup_Attempt = (RadioGroup) findViewById(R.id.radioSex2);

        final CheckBox Played_Defense_Bx = (CheckBox) findViewById(R.id.Play_Defense);
        final CheckBox Robot_Stall = (CheckBox) findViewById(R.id.Robot_Stall);
        final CheckBox Robot_Tip = (CheckBox) findViewById(R.id.Robot_Tip);
        final CheckBox Attempted_Climb = (CheckBox) findViewById(R.id.Attempted_Climb);
        final CheckBox Defensive_Fouls = (CheckBox) findViewById(R.id.Defensive_Fouls);

        Attempted_Climb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Attempted_Climb.isChecked()) {
                    RadioGroup_Attempt.setVisibility(View.VISIBLE);
                } else {
                    RadioGroup_Attempt.setVisibility(View.GONE);
                }
            }
        });


        Button To_Submission = (Button) findViewById(R.id.To_Submission); //Defines button for later use
        To_Submission.setOnClickListener(new View.OnClickListener() { //Makes onclick listener for button
            @Override
            public void onClick(View v) {
                if (Attempted_Climb.isChecked()) {
                    if (Attempt_Level_Two.isChecked()) {
                        Robot_Attempted_Climb = "Attempt 2";
                    }
                    if (Attempt_Level_Three.isChecked()) {
                        Robot_Attempted_Climb = "Attempt 3";
                    }
                }

                if (Hab_Level_One.isChecked()) {
                    Ending_HAB_Location = "1";
                }
                if (Hab_Level_Two.isChecked()) {
                    Ending_HAB_Location = "2";
                }
                if (Hab_Level_Three.isChecked()) {
                    Ending_HAB_Location = "3";
                }
                if (No_Hab.isChecked()) {
                    Ending_HAB_Location = "Didn't end on HAB";
                }

                if (Played_Defense_Bx.isChecked()) {
                    Played_Defense = "TRUE";
                }
                if (Defensive_Fouls.isChecked()){
                    def_foul = "TRUE";
                }
                if (Robot_Stall.isChecked()) {
                    Robot_Stalled = "TRUE";
                }
                if (Robot_Tip.isChecked()) {
                    Robot_Tipped = "TRUE";
                }

                Intent startintent = new Intent(getApplicationContext(), Save_Page.class);
                startActivity(startintent);
            }
        });


    }

}


